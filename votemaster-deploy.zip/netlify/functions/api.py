"""
Netlify serverless function — handles all /api/* routes for VoteMaster.

Netlify bundles the 'scrapers/' directory alongside this file via
'included_files' in netlify.toml, so all scrapers are importable.
"""

from __future__ import annotations
import json
import os
import re
import sys
import traceback

# ── Make scrapers importable from Lambda bundle ───────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
for _p in [_HERE, "/var/task"]:
    if os.path.isdir(os.path.join(_p, "scrapers")) and _p not in sys.path:
        sys.path.insert(0, _p)
        break

from scrapers.eci_scraper                     import ECIScraper
from scrapers.news_scraper                    import NewsScraper
from scrapers.historical_scraper              import HistoricalScraper
from scrapers.opinion_poll_scraper            import OpinionPollScraper
from scrapers.historical_constituency_scraper import HistoricalConstituencyScraper

# ── Scraper singletons (re-used within a warm Lambda invocation) ──────────────
_eci       = ECIScraper(timeout=15)
_news      = NewsScraper(max_per_feed=20, timeout=10)
_hist      = HistoricalScraper()
_opinion   = OpinionPollScraper()
_hist_const = HistoricalConstituencyScraper(timeout=25)

# ── Helpers ───────────────────────────────────────────────────────────────────

def _ok(data, status=200):
    return {
        "statusCode": status,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(data, default=str),
    }

def _err(msg, status=500):
    return _ok({"error": msg}, status)

def _norm(s: str) -> str:
    s = (s or "").upper()
    s = re.sub(r"^\d+\s*[-–.]\s*", "", s)
    s = re.sub(r"[^A-Z0-9 ]", " ", s)
    return re.sub(r"\s+", " ", s).strip()

# ── Map data constants (copied from app.py) ───────────────────────────────────

_STATE_SLUG = {
    "WB2026": "WEST BENGAL",   "KL2026": "KERALA",
    "TN2026": "TAMIL NADU",    "AS2026": "ASSAM",
    "MH2024": "MAHARASHTRA",   "JH2024": "JHARKHAND",
    "AP2024": "ANDHRA PRADESH","OD2024": "ODISHA",
    "AR2024": "ARUNACHAL PRADESH","SK2024": "SIKKIM",
    "LS2024": None,
    "RJ2023": "RAJASTHAN",     "MP2023": "MADHYA PRADESH",
    "CG2023": "CHHATTISGARH",  "TG2023": "TELANGANA",
    "KA2023": "KARNATAKA",     "MZ2023": "MIZORAM",
    "NL2023": "NAGALAND",      "MN2023": "MANIPUR",
    "MG2023": "MEGHALAYA",     "TR2023": "TRIPURA",
    "UP2022": "UTTAR PRADESH", "PB2022": "PUNJAB",
    "GA2022": "GOA",           "UA2022": "UTTARAKHAND",
    "HP2022": "HIMACHAL PRADESH","GJ2022": "GUJARAT",
    "WB2021": "WEST BENGAL",   "KL2021": "KERALA",
    "TN2021": "TAMIL NADU",    "AS2021": "ASSAM",
    "DL2020": "DELHI",         "BR2020": "BIHAR",
    "HR2019": "HARYANA",       "MH2019": "MAHARASHTRA",
    "JH2019": "JHARKHAND",     "LS2019": None,
    "DL2025": "DELHI",         "BR2025": "BIHAR",
}

_ASSEMBLY_GEOJSON = (
    "https://raw.githubusercontent.com/datta07/INDIAN-SHAPEFILES"
    "/master/STATES/{state}/{state}_ASSEMBLY.geojson"
)
_INDIA_STATES_GEOJSON = (
    "https://raw.githubusercontent.com/datta07/INDIAN-SHAPEFILES"
    "/master/INDIA/India_State_Boundary.geojson"
)

_LS2024_STATE = {
    "ANDHRA PRADESH":    {"party":"TDP",   "seats":16,"total":25,"colour":"#FFD700"},
    "ARUNACHAL PRADESH": {"party":"BJP",   "seats": 2,"total": 2,"colour":"#FF9933"},
    "ASSAM":             {"party":"BJP",   "seats": 9,"total":14,"colour":"#FF9933"},
    "BIHAR":             {"party":"NDA",   "seats":30,"total":40,"colour":"#FF9933"},
    "CHHATTISGARH":      {"party":"BJP",   "seats":10,"total":11,"colour":"#FF9933"},
    "GOA":               {"party":"BJP",   "seats": 2,"total": 2,"colour":"#FF9933"},
    "GUJARAT":           {"party":"BJP",   "seats":26,"total":26,"colour":"#FF9933"},
    "HARYANA":           {"party":"BJP",   "seats": 5,"total":10,"colour":"#FF9933"},
    "HIMACHAL PRADESH":  {"party":"INC",   "seats": 4,"total": 4,"colour":"#3498db"},
    "JHARKHAND":         {"party":"JMM",   "seats": 3,"total":14,"colour":"#27ae60"},
    "KARNATAKA":         {"party":"INC",   "seats": 9,"total":28,"colour":"#3498db"},
    "KERALA":            {"party":"INC",   "seats":18,"total":20,"colour":"#3498db"},
    "MADHYA PRADESH":    {"party":"BJP",   "seats":29,"total":29,"colour":"#FF9933"},
    "MAHARASHTRA":       {"party":"MVP",   "seats":17,"total":48,"colour":"#FF9933"},
    "MANIPUR":           {"party":"BJP",   "seats": 2,"total": 2,"colour":"#FF9933"},
    "MEGHALAYA":         {"party":"NPP",   "seats": 2,"total": 2,"colour":"#8e44ad"},
    "MIZORAM":           {"party":"ZPM",   "seats": 1,"total": 1,"colour":"#16a085"},
    "NAGALAND":          {"party":"NDPP",  "seats": 1,"total": 1,"colour":"#2c3e50"},
    "ODISHA":            {"party":"BJD",   "seats":12,"total":21,"colour":"#27ae60"},
    "PUNJAB":            {"party":"AAP",   "seats": 7,"total":13,"colour":"#00bfff"},
    "RAJASTHAN":         {"party":"BJP",   "seats":14,"total":25,"colour":"#FF9933"},
    "SIKKIM":            {"party":"SKM",   "seats": 1,"total": 1,"colour":"#8e44ad"},
    "TAMIL NADU":        {"party":"DMK",   "seats":22,"total":39,"colour":"#e74c3c"},
    "TELANGANA":         {"party":"INC",   "seats": 8,"total":17,"colour":"#3498db"},
    "TRIPURA":           {"party":"BJP",   "seats": 2,"total": 2,"colour":"#FF9933"},
    "UTTAR PRADESH":     {"party":"SP",    "seats":37,"total":80,"colour":"#e74c3c"},
    "UTTARAKHAND":       {"party":"BJP",   "seats": 5,"total": 5,"colour":"#FF9933"},
    "WEST BENGAL":       {"party":"TMC",   "seats":29,"total":42,"colour":"#1E90FF"},
    "DELHI":             {"party":"BJP",   "seats": 7,"total": 7,"colour":"#FF9933"},
    "JAMMU & KASHMIR":   {"party":"INC",   "seats": 2,"total": 5,"colour":"#3498db"},
    "LADAKH":            {"party":"IND",   "seats": 1,"total": 1,"colour":"#7f8c8d"},
}

_LS2019_STATE = {
    "ANDHRA PRADESH":    {"party":"YSRCP","seats":22,"total":25,"colour":"#27ae60"},
    "ARUNACHAL PRADESH": {"party":"BJP",  "seats": 2,"total": 2,"colour":"#FF9933"},
    "ASSAM":             {"party":"BJP",  "seats": 9,"total":14,"colour":"#FF9933"},
    "BIHAR":             {"party":"NDA",  "seats":39,"total":40,"colour":"#FF9933"},
    "CHHATTISGARH":      {"party":"BJP",  "seats": 9,"total":11,"colour":"#FF9933"},
    "GOA":               {"party":"BJP",  "seats": 2,"total": 2,"colour":"#FF9933"},
    "GUJARAT":           {"party":"BJP",  "seats":26,"total":26,"colour":"#FF9933"},
    "HARYANA":           {"party":"BJP",  "seats":10,"total":10,"colour":"#FF9933"},
    "HIMACHAL PRADESH":  {"party":"BJP",  "seats": 4,"total": 4,"colour":"#FF9933"},
    "JHARKHAND":         {"party":"BJP",  "seats":11,"total":14,"colour":"#FF9933"},
    "KARNATAKA":         {"party":"BJP",  "seats":25,"total":28,"colour":"#FF9933"},
    "KERALA":            {"party":"INC",  "seats":15,"total":20,"colour":"#3498db"},
    "MADHYA PRADESH":    {"party":"BJP",  "seats":28,"total":29,"colour":"#FF9933"},
    "MAHARASHTRA":       {"party":"BJP",  "seats":23,"total":48,"colour":"#FF9933"},
    "MANIPUR":           {"party":"BJP",  "seats": 2,"total": 2,"colour":"#FF9933"},
    "MEGHALAYA":         {"party":"NPP",  "seats": 2,"total": 2,"colour":"#8e44ad"},
    "MIZORAM":           {"party":"MNF",  "seats": 1,"total": 1,"colour":"#16a085"},
    "NAGALAND":          {"party":"NDPP", "seats": 1,"total": 1,"colour":"#2c3e50"},
    "ODISHA":            {"party":"BJD",  "seats":12,"total":21,"colour":"#27ae60"},
    "PUNJAB":            {"party":"INC",  "seats": 8,"total":13,"colour":"#3498db"},
    "RAJASTHAN":         {"party":"BJP",  "seats":24,"total":25,"colour":"#FF9933"},
    "SIKKIM":            {"party":"SKM",  "seats": 1,"total": 1,"colour":"#8e44ad"},
    "TAMIL NADU":        {"party":"ADMK", "seats":23,"total":39,"colour":"#8e44ad"},
    "TELANGANA":         {"party":"TRS",  "seats": 9,"total":17,"colour":"#e74c3c"},
    "TRIPURA":           {"party":"BJP",  "seats": 2,"total": 2,"colour":"#FF9933"},
    "UTTAR PRADESH":     {"party":"BJP",  "seats":62,"total":80,"colour":"#FF9933"},
    "UTTARAKHAND":       {"party":"BJP",  "seats": 5,"total": 5,"colour":"#FF9933"},
    "WEST BENGAL":       {"party":"BJP",  "seats":18,"total":42,"colour":"#FF9933"},
    "DELHI":             {"party":"BJP",  "seats": 7,"total": 7,"colour":"#FF9933"},
    "JAMMU & KASHMIR":   {"party":"BJP",  "seats": 3,"total": 6,"colour":"#FF9933"},
}

_LS_STATE_DATA = {"LS2024": _LS2024_STATE, "LS2019": _LS2019_STATE}

# ── Route handlers ────────────────────────────────────────────────────────────

def handle_elections():
    data = _eci.get_elections()
    from datetime import datetime, timezone
    return _ok({"data": data, "last_updated": datetime.now(timezone.utc).isoformat()})


def handle_partywise(params):
    idx  = int(params.get("idx", 0))
    elections = _eci.get_elections()
    if idx < len(elections):
        data = _eci.get_partywise_results(elections[idx])
    else:
        data = []
    is_demo = any(r.get("demo") for r in (data or []))
    return _ok({"data": data, "demo": is_demo})


def handle_constituencies(params):
    idx = int(params.get("idx", 0))
    elections = _eci.get_elections()
    if idx < len(elections):
        data = _eci.get_constituency_results(elections[idx])
    else:
        data = []
    is_demo = any(r.get("demo") for r in (data or []))
    return _ok({"data": data, "demo": is_demo})


def handle_hist_elections():
    return _ok({"data": _hist.get_all_elections()})


def handle_hist_partywise(params):
    eid      = params.get("id", "")
    use_wiki = params.get("wiki", "false").lower() == "true"
    election = _hist.get_election(eid)
    if not election:
        return _err("Election not found", 404)
    partywise = _hist.get_partywise(eid, try_wikipedia=use_wiki)
    return _ok({
        "data":      partywise,
        "alliances": election.get("alliances"),
        "meta": {
            "id":          election["id"],
            "name":        election["name"],
            "date":        election["date"],
            "total_seats": election["total_seats"],
            "majority":    election["majority"],
            "winner":      election["winner"],
            "type":        election["type"],
        },
    })


def handle_hist_search(params):
    q = params.get("q", "")
    return _ok({"data": _hist.search_elections(q)})


def handle_news(params):
    articles   = _news.get_election_news(filter_keywords=False)
    election_id = params.get("election_id", "")
    keywords    = params.get("keywords", "")
    if election_id:
        election = _hist.get_election(election_id)
        if election:
            kws = election.get("keywords", [])
            articles = [
                a for a in articles
                if any(kw in (a["title"] + a.get("summary","")).lower() for kw in kws)
            ]
    if keywords:
        kws = [k.strip().lower() for k in keywords.split(",") if k.strip()]
        articles = [
            a for a in articles
            if any(kw in (a["title"] + a.get("summary","")).lower() for kw in kws)
        ]
    from datetime import datetime, timezone
    return _ok({"data": articles,
                "last_updated": datetime.now(timezone.utc).isoformat()})


def handle_polls(params):
    election_id = params.get("election_id", "")
    if election_id:
        return _ok({
            "election_id": election_id,
            "polls":       _opinion.get_polls(election_id),
            "aggregate":   _opinion.get_aggregate(election_id),
        })
    return _ok({
        "elections": _opinion.get_elections_with_polls(),
        "polls":     _opinion.get_polls(),
    })


def handle_map_data(election_id):
    state_slug = _STATE_SLUG.get(election_id)
    is_ls      = election_id.startswith("LS")

    if is_ls:
        ls_data    = _LS_STATE_DATA.get(election_id, {})
        result_map = {}
        for state_name, d in ls_data.items():
            key = _norm(state_name)
            result_map[key] = {
                "constituency":       state_name,
                "leading_candidate":  f"{d['seats']} seats",
                "leading_party":      d["party"],
                "trailing_candidate": f"out of {d['total']} seats",
                "trailing_party":     "",
                "margin":             "",
                "status":             "Won",
                "colour":             d["colour"],
            }
        return _ok({
            "election_id":   election_id,
            "state":         "INDIA",
            "geojson_url":   _INDIA_STATES_GEOJSON,
            "result_map":    result_map,
            "party_colours": {},
            "type":          "lok_sabha",
            "map_note":      "Each state is coloured by its leading party.",
        })

    geojson_url = None
    if state_slug:
        geojson_url = _ASSEMBLY_GEOJSON.format(
            state=state_slug.replace(" ", "%20")
        )

    is_historical  = bool(_hist.get_election(election_id))
    result_map     = {}

    if not is_historical:
        # Live: scrape ECI
        elections = _eci.get_elections()
        for e in elections:
            if e.get("id") == election_id:
                const_data = _eci.get_constituency_results(e)
                for r in (const_data or []):
                    key = _norm(r.get("constituency", ""))
                    if key:
                        result_map[key] = r
                break
    else:
        # Historical: IndiaVotes → ECI archive fallback
        const_data = _hist_const.get_constituencies(election_id)
        for r in (const_data or []):
            key = _norm(r.get("constituency", ""))
            if key:
                result_map[key] = r

    party_colours = {}
    if is_historical:
        elec = _hist.get_election(election_id)
        for p in (elec or {}).get("partywise", []):
            party_colours[p["party"]] = p["colour"]

    has_archive = _hist_const.is_available(election_id)
    map_note    = None
    if is_historical and not result_map:
        map_note = ("Fetching constituency data — may take a moment on first load"
                    if has_archive else
                    "Constituency data not available for this election")

    return _ok({
        "election_id":   election_id,
        "state":         state_slug,
        "geojson_url":   geojson_url,
        "result_map":    result_map,
        "party_colours": party_colours,
        "type":          "historical" if is_historical else "live",
        "map_note":      map_note,
        "has_archive":   has_archive,
    })


def handle_status():
    from datetime import datetime, timezone
    return _ok({
        "status":       "ok",
        "last_updated": datetime.now(timezone.utc).isoformat(),
        "platform":     "netlify",
    })


# ── Main router ───────────────────────────────────────────────────────────────

def handler(event, context):
    # Handle CORS preflight
    if event.get("httpMethod") == "OPTIONS":
        return {
            "statusCode": 204,
            "headers": {
                "Access-Control-Allow-Origin":  "*",
                "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
            "body": "",
        }

    path   = event.get("path", "")
    params = event.get("queryStringParameters") or {}

    # Strip leading /api prefix for routing
    route = re.sub(r"^/api", "", path).rstrip("/")

    try:
        if route == "/elections":
            return handle_elections()
        elif route == "/partywise":
            return handle_partywise(params)
        elif route == "/constituencies":
            return handle_constituencies(params)
        elif route == "/historical/elections":
            return handle_hist_elections()
        elif route == "/historical/partywise":
            return handle_hist_partywise(params)
        elif route == "/historical/search":
            return handle_hist_search(params)
        elif route == "/news":
            return handle_news(params)
        elif route == "/polls":
            return handle_polls(params)
        elif route.startswith("/map-data/"):
            election_id = route.split("/map-data/", 1)[-1]
            return handle_map_data(election_id)
        elif route == "/status":
            return handle_status()
        elif route == "/refresh":
            return _ok({"status": "ok", "message": "No background refresh in serverless mode"})
        else:
            return _err(f"Unknown route: {path}", 404)

    except Exception as exc:
        tb = traceback.format_exc()
        print(f"[api] Error on {path}: {exc}\n{tb}")
        return _err(str(exc), 500)
